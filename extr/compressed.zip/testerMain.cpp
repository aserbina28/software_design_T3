#include "review.h"

// Man function for call to ReadStdIn
int main(int argc, char* argv[]) {

    ReadStdIn();
    return 0;

}